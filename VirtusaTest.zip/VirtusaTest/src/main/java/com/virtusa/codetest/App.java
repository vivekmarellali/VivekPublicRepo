package com.virtusa.codetest;
import java.text.NumberFormat;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       	int n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number to convert into word format");
		n =s.nextInt();
		System.out.println(NumberFormat.getInstance().format(n) + "='" + NumberToWordsConverter.convert(n) + "'");
    }


}
