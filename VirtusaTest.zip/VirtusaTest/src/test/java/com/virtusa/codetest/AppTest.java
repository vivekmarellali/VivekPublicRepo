package com.virtusa.codetest;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.framework.Assert;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
		String result = NumberToWordsConverter.convert(10);
		Assert.assertEquals("Test failed","ten",result);
		result = NumberToWordsConverter.convert(19);
		Assert.assertEquals("Test failed","nineteen",result);
		result = NumberToWordsConverter.convert(20);
		Assert.assertEquals("Test failed","twenty",result);
		result = NumberToWordsConverter.convert(99);
		Assert.assertEquals("Test failed","ninety nine",result);
		result = NumberToWordsConverter.convert(100);
		Assert.assertEquals("Test failed","one hundred",result);
		result = NumberToWordsConverter.convert(101);
		Assert.assertEquals("Test failed","one hundred and one",result);
		result = NumberToWordsConverter.convert(999);
		Assert.assertEquals("Test failed","nine hundred and ninety nine",result);
		result = NumberToWordsConverter.convert(1000);
		Assert.assertEquals("Test failed","one thousand",result);
		result = NumberToWordsConverter.convert(1001);
		Assert.assertEquals("Test failed","one thousand and one",result);
		result = NumberToWordsConverter.convert(1999);
		Assert.assertEquals("Test failed","one thousand and nine hundred and ninety nine",result);
		result = NumberToWordsConverter.convert(10000);
		Assert.assertEquals("Test failed","ten thousand",result);
		result = NumberToWordsConverter.convert(19999);
		Assert.assertEquals("Test failed","nineteen thousand and nine hundred and ninety nine",result);
		result = NumberToWordsConverter.convert(99999);
		Assert.assertEquals("Test failed","ninety nine thousand and nine hundred and ninety nine",result);
		result = NumberToWordsConverter.convert(100000);
		Assert.assertEquals("Test failed","one hundred thousand",result);
		result = NumberToWordsConverter.convert(999999);
		Assert.assertEquals("Test failed","nine hundred and ninety nine thousand and nine hundred and ninety nine",result);
	    result = NumberToWordsConverter.convert(1000000);
		Assert.assertEquals("Test failed","one million",result);
	    result = NumberToWordsConverter.convert(1000001);
		Assert.assertEquals("Test failed","one million and one",result);
	    result = NumberToWordsConverter.convert(19000001);
		Assert.assertEquals("Test failed","nineteen million and one",result);
	    result = NumberToWordsConverter.convert(20000000);
		Assert.assertEquals("Test failed","twenty million",result);
	    result = NumberToWordsConverter.convert(99000000);
		Assert.assertEquals("Test failed","ninety nine million",result);
	    result = NumberToWordsConverter.convert(100000000);
		Assert.assertEquals("Test failed","one hundred million",result);
	    result = NumberToWordsConverter.convert(999999999);
		Assert.assertEquals("Test failed","nine hundred and ninety nine million and nine hundred and ninety nine thousand and nine hundred and ninety nine",result);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );
    }
}
